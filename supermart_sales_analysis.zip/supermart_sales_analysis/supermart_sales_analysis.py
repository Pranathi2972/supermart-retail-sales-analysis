# Supermart Grocery Sales Analysis
# Author: Pranathi Unnikrishnan

# STEP A: Import required libraries
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

print("Step A complete: Libraries imported")

# STEP B: Load the dataset
df = pd.read_csv("data/Supermart Grocery Sales - Retail Analytics Dataset.csv")

print("Step B complete: Dataset loaded")
print("Shape:", df.shape)
print(df.head())

# STEP C: Dataset basic information
print("\nStep C: Dataset Info")
print(df.info())

print("\nFirst 10 column names:")
print(df.columns)

print("\nMissing values per column:")
print(df.isnull().sum())

# STEP D: Convert Order Date to datetime (safe for mixed formats)
df["Order Date"] = pd.to_datetime(df["Order Date"], format="mixed", errors="coerce")
print("Invalid dates:", df["Order Date"].isna().sum())


print("\nStep D complete: Order Date converted")
print(df["Order Date"].head())

# STEP E: Create Year and Month columns
df["Year"] = df["Order Date"].dt.year
df["Month"] = df["Order Date"].dt.month

print("\nStep E complete: Year and Month created")
print(df[["Order Date", "Year", "Month"]].head())

# STEP F: Handle missing values
df = df.fillna(0)

print("\nStep F complete: Missing values handled")
print(df.isnull().sum())

# STEP G: Remove duplicate rows
before = df.shape[0]
df = df.drop_duplicates()
after = df.shape[0]

print(f"\nStep G complete: Removed {before - after} duplicate rows")
print("Remaining rows:", after)

# STEP H: Sales by Category
category_sales = df.groupby("Category")["Sales"].sum().sort_values(ascending=False)

plt.figure(figsize=(8, 5))
sns.barplot(x=category_sales.values, y=category_sales.index)
plt.title("Total Sales by Category")
plt.xlabel("Total Sales")
plt.ylabel("Category")
plt.tight_layout()
plt.savefig("outputs/plots/sales_by_category.png")
plt.close()

print("Step H complete: Sales by category plot saved")

# STEP I: Top 10 Cities by Sales
city_sales = df.groupby("City")["Sales"].sum().sort_values(ascending=False).head(10)

plt.figure(figsize=(8, 5))
sns.barplot(x=city_sales.values, y=city_sales.index)
plt.title("Top 10 Cities by Total Sales")
plt.xlabel("Total Sales")
plt.ylabel("City")
plt.tight_layout()
plt.savefig("outputs/plots/top_10_cities_sales.png")
plt.close()

print("Step I complete: Top cities plot saved")

# STEP J: Yearly Sales Trend
yearly_sales = df.groupby("Year")["Sales"].sum()

plt.figure(figsize=(8, 5))
yearly_sales.plot(marker="o")
plt.title("Yearly Sales Trend")
plt.xlabel("Year")
plt.ylabel("Total Sales")
plt.grid(True)
plt.tight_layout()
plt.savefig("outputs/plots/yearly_sales_trend.png")
plt.close()

print("Step J complete: Yearly sales trend plot saved")

# STEP K: Discount vs Profit
plt.figure(figsize=(8, 5))
sns.scatterplot(x=df["Discount"], y=df["Profit"], alpha=0.4)
plt.title("Discount vs Profit")
plt.xlabel("Discount")
plt.ylabel("Profit")
plt.tight_layout()
plt.savefig("outputs/plots/discount_vs_profit.png")
plt.close()

print("Step K complete: Discount vs profit plot saved")

# STEP L: Profit by Category
category_profit = df.groupby("Category")["Profit"].sum().sort_values(ascending=False)

plt.figure(figsize=(8, 5))
sns.barplot(x=category_profit.values, y=category_profit.index)
plt.title("Total Profit by Category")
plt.xlabel("Total Profit")
plt.ylabel("Category")
plt.tight_layout()
plt.savefig("outputs/plots/profit_by_category.png")
plt.close()

print("Step L complete: Profit by category plot saved")

# STEP M: Feature selection
features = ["Category", "City", "Discount", "Year", "Month"]
target = "Sales"

X = df[features]
y = df[target]

print("\nStep M complete: Features and target selected")
print("X shape:", X.shape)
print("y shape:", y.shape)

# STEP N: Encode categorical variables
X_encoded = pd.get_dummies(X, drop_first=True)

print("Step N complete: Categorical variables encoded")
print("Encoded feature shape:", X_encoded.shape)

# STEP O: Train-test split
from sklearn.model_selection import train_test_split

X_train, X_test, y_train, y_test = train_test_split(
    X_encoded, y, test_size=0.2, random_state=42
)

print("Step O complete: Train-test split done")

# STEP P: Train Linear Regression model
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import math

lr_model = LinearRegression()
lr_model.fit(X_train, y_train)

print("Step P complete: Linear Regression model trained")

# STEP Q: Model evaluation
y_pred = lr_model.predict(X_test)

mae = mean_absolute_error(y_test, y_pred)
rmse = math.sqrt(mean_squared_error(y_test, y_pred))
r2 = r2_score(y_test, y_pred)

print("\n===== Linear Regression Results =====")
print("MAE:", round(mae, 2))
print("RMSE:", round(rmse, 2))
print("R² Score:", round(r2, 4))

# STEP R: Actual vs Predicted Sales plot
plt.figure(figsize=(6, 6))
plt.scatter(y_test, y_pred, alpha=0.4)
plt.xlabel("Actual Sales")
plt.ylabel("Predicted Sales")
plt.title("Actual vs Predicted Sales")
plt.tight_layout()
plt.savefig("outputs/plots/lr_actual_vs_pred_sales.png")
plt.close()

print("Step R complete: Prediction plot saved")

# ================================
# UPGRADE STEP A: Feature Engineering
# ================================

# Create Profit Margin feature
df["Profit_Margin"] = df["Profit"] / df["Sales"]

# Replace infinities or NaN (safe handling)
df["Profit_Margin"] = df["Profit_Margin"].replace([np.inf, -np.inf], 0)
df["Profit_Margin"] = df["Profit_Margin"].fillna(0)

print("\nUpgrade A complete: Profit_Margin feature created")
print(df[["Sales", "Profit", "Profit_Margin"]].head())

# ================================
# UPGRADE STEP B: Random Forest Model
# ================================

# New feature set
rf_features = [
    "Discount",
    "Year",
    "Month",
    "Profit_Margin",
    "Category",
    "City"
]

X_rf = df[rf_features]
y_rf = df["Sales"]

print("\nUpgrade B1 complete: RF features selected")
print("X_rf shape:", X_rf.shape)

# Encode categorical variables
X_rf_encoded = pd.get_dummies(X_rf, drop_first=True)

print("Upgrade B2 complete: Categorical features encoded")
print("Encoded shape:", X_rf_encoded.shape)

from sklearn.model_selection import train_test_split

X_train_rf, X_test_rf, y_train_rf, y_test_rf = train_test_split(
    X_rf_encoded, y_rf, test_size=0.2, random_state=42
)

print("Upgrade B3 complete: Train-test split done")

from sklearn.ensemble import RandomForestRegressor

rf_model = RandomForestRegressor(
    n_estimators=200,
    random_state=42,
    n_jobs=-1
)

rf_model.fit(X_train_rf, y_train_rf)

print("Upgrade B4 complete: Random Forest trained")

from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import math

rf_pred = rf_model.predict(X_test_rf)

rf_mae = mean_absolute_error(y_test_rf, rf_pred)
rf_rmse = math.sqrt(mean_squared_error(y_test_rf, rf_pred))
rf_r2 = r2_score(y_test_rf, rf_pred)

print("\n===== Random Forest Results =====")
print("MAE:", round(rf_mae, 2))
print("RMSE:", round(rf_rmse, 2))
print("R² Score:", round(rf_r2, 4))

# Actual vs Predicted plot (Random Forest)
plt.figure(figsize=(6, 6))
plt.scatter(y_test_rf, rf_pred, alpha=0.4)
plt.xlabel("Actual Sales")
plt.ylabel("Predicted Sales")
plt.title("Actual vs Predicted Sales (Random Forest)")
plt.tight_layout()
plt.savefig("outputs/plots/rf_actual_vs_pred_sales.png")
plt.close()

print("Upgrade B6 complete: RF prediction plot saved")

# ================================
# FINAL UPGRADE: Sales Classification
# ================================

# Create Sales Category (Low / Medium / High)
df["Sales_Category"] = pd.qcut(
    df["Sales"],
    q=3,
    labels=["Low", "Medium", "High"]
)

print("\nSales Category distribution:")
print(df["Sales_Category"].value_counts())

from sklearn.preprocessing import LabelEncoder

features_cls = ["Category", "City", "Discount", "Year", "Month", "Profit_Margin"]
X_cls = df[features_cls]
y_cls = df["Sales_Category"]

# Encode categorical features
X_cls_encoded = pd.get_dummies(X_cls, drop_first=True)

# Encode target
le = LabelEncoder()
y_cls_encoded = le.fit_transform(y_cls)

print("Classification data prepared")

from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report

X_train_c, X_test_c, y_train_c, y_test_c = train_test_split(
    X_cls_encoded, y_cls_encoded, test_size=0.2, random_state=42
)

rf_clf = RandomForestClassifier(
    n_estimators=200,
    random_state=42,
    n_jobs=-1
)

rf_clf.fit(X_train_c, y_train_c)

y_pred_c = rf_clf.predict(X_test_c)

print("\n===== Random Forest Classification Results =====")
print("Accuracy:", round(accuracy_score(y_test_c, y_pred_c), 4))
print("\nClassification Report:\n", classification_report(y_test_c, y_pred_c))

# ================================
# SMART FIX: Aggregate-Level Modeling
# ================================

# Aggregate sales monthly by City & Category
agg_df = (
    df.groupby(["Year", "Month", "City", "Category"])
    .agg({
        "Sales": "sum",
        "Profit": "sum",
        "Discount": "mean",
        "Profit_Margin": "mean"
    })
    .reset_index()
)

print("Aggregated data shape:", agg_df.shape)
print(agg_df.head())

# Features & target
X_agg = agg_df[["Discount", "Profit_Margin", "Year", "Month", "City", "Category"]]
y_agg = agg_df["Sales"]

# Encode categorical variables
X_agg_encoded = pd.get_dummies(X_agg, drop_first=True)

from sklearn.model_selection import train_test_split
X_train_a, X_test_a, y_train_a, y_test_a = train_test_split(
    X_agg_encoded, y_agg, test_size=0.2, random_state=42
)

# Train Random Forest
from sklearn.ensemble import RandomForestRegressor
rf_agg = RandomForestRegressor(
    n_estimators=300,
    random_state=42,
    n_jobs=-1
)
rf_agg.fit(X_train_a, y_train_a)

# Evaluate
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import math

pred_a = rf_agg.predict(X_test_a)

print("\n===== Aggregated Random Forest Results =====")
print("MAE:", round(mean_absolute_error(y_test_a, pred_a), 2))
print("RMSE:", round(math.sqrt(mean_squared_error(y_test_a, pred_a)), 2))
print("R² Score:", round(r2_score(y_test_a, pred_a), 4))
